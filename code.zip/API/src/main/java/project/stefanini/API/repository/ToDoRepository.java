/* Consultas basicas no banco de dados */

package project.stefanini.API.repository;

import org.springframework.data.repository.CrudRepository;
import project.stefanini.API.model.ToDoModel;

public interface ToDoRepository extends CrudRepository <ToDoModel, Integer>{

}
