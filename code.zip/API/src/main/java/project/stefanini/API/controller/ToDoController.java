/* Metodos para a requisicao na API */

package project.stefanini.API.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.stefanini.API.model.ToDoModel;
import project.stefanini.API.repository.ToDoRepository;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@RestController
public class ToDoController {

    @Autowired
    private ToDoRepository repository;

    @GetMapping(path = "/api/todo/{id}")
    public ResponseEntity consult(@PathVariable("id") Integer id){
        return repository.findById(id).map(record -> ResponseEntity.ok().body(record))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping(path = "/api/todo/all")
    public ResponseEntity consult(){
        List<ToDoModel> todos = StreamSupport.stream(repository.findAll().spliterator(), false)
                .collect(Collectors.toList());
        return !todos.isEmpty() ? ResponseEntity.ok().body(todos) : ResponseEntity.notFound().build();
    }

    @PostMapping(path = "/api/todo/save")
    public ToDoModel save(@RequestBody ToDoModel ToDo){
        return repository.save(ToDo);
    }
}
