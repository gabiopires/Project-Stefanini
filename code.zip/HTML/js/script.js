// Funcao para limpar e esconder a tabela criada anteriormente
function clearAndHideTable() {
    const existingTable = document.querySelector('table');
    if (existingTable) {
        existingTable.parentNode.removeChild(existingTable);
    }
}

// Funcao para limpar o formulario de cadastro
function clearCadastroForm() {
    document.getElementById('id').value = '';
    document.getElementById('title').value = '';
    document.getElementById('description').value = '';
    document.getElementById('status').selectedIndex = 0;
}

// Funcao para limpar o formulario de pesquisa
function clearPesquisaForm() {
    document.getElementById('idpesq').value = '';
}

// Funcao botao Cadastrar Tarefa
document.getElementById('cadastro').addEventListener('click', function () {
    clearAndHideTable();
    clearCadastroForm();
    document.getElementById('form').style.display = 'block';
    document.getElementById('list').style.display = 'none';
});

// Funcao botao Pesquisar Tarefa
document.getElementById('pesquisar').addEventListener('click', function () {
    clearAndHideTable();
    clearPesquisaForm();
    document.getElementById('form').style.display = 'none';
    document.getElementById('list').style.display = 'block';
});

// Funcao botao Listar Tarefas
document.getElementById('listar').addEventListener('click', function () {
    clearAndHideTable();
    fetchAndDisplayAllTasks();
    document.getElementById('form').style.display = 'none';
    document.getElementById('list').style.display = 'none';
});

// Funcao para cadastrar uma tarefa
document.getElementById('enviar').addEventListener('click', function (event) {
    event.preventDefault();

    var id = document.getElementById('id').value;
    var title = document.getElementById('title').value;
    var description = document.getElementById('description').value;
    var status = document.getElementById('status').value;

    if (!id || !title || !description) {
        alert("Preencha todos os campos");
        return;
    }

    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        id: id,
        title: title,
        description: description,
        status: status
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("http://localhost:8080/api/todo/save", requestOptions)
        .then(response => response.json())
        .then(result => {
            alert("Cadastro realizado com sucesso!");
            clearCadastroForm();
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Erro ao executar");
        });
});

// Funcao para buscar uma tarefa especifica
document.getElementById('buscar').addEventListener('click', function () {
    var idpesq = document.getElementById('idpesq').value;

    if (!idpesq) {
        alert("Preencha o ID");
        return;
    }

    fetch(`http://localhost:8080/api/todo/${idpesq}`)
        .then(response => response.json())
        .then(data => {
            displayDataAsTable([data]);
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Erro ao executar a pesquisa");
        });
});

// Funcao para buscar e exibir todas as tarefas
function fetchAndDisplayAllTasks() {
    fetch('http://localhost:8080/api/todo/all')
        .then(response => response.json())
        .then(data => {
            displayDataAsTable(data);
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Erro ao executar a listagem");
        });
}

// Funcao para exibir os dados como uma tabela
function displayDataAsTable(data) {
    clearAndHideTable();

    const table = document.createElement('table');
    const thead = document.createElement('thead');
    const tbody = document.createElement('tbody');
    const trHead = document.createElement('tr');

    ['ID', 'Título', 'Descrição', 'Status'].forEach(text => {
        const th = document.createElement('th');
        th.textContent = text;
        trHead.appendChild(th);
    });
    thead.appendChild(trHead);

    data.forEach(item => {
        const trBody = document.createElement('tr');
        ['id', 'title', 'description', 'status'].forEach(prop => {
            const td = document.createElement('td');
            td.textContent = item[prop] || '';
            trBody.appendChild(td);
        });
        tbody.appendChild(trBody);
    });

    table.appendChild(thead);
    table.appendChild(tbody);
    document.body.appendChild(table);
}
